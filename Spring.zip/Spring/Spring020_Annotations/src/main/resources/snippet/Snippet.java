package snippet;

public class Snippet {
	public static void main(String[] args) {
		   <dependencies>
	}
}

