package com.cg.java.tests;

import org.springframework.context.ApplicationContext;
import org.springframework.context.ConfigurableApplicationContext;
import org.springframework.context.annotation.AnnotationConfigApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

import com.cg.java.config.ProjectConfig;
import com.cg.java.dao.EmpDao;
import com.cg.java.exceptions.EmpException;
import com.cg.java.services.EmpService;

public class Test050 {

	public static void main(String[] args) {
		ConfigurableApplicationContext ctx=new AnnotationConfigApplicationContext(ProjectConfig.class);
	System.out.println("**********************************");
		
		/*EmpDao dao1=ctx.getBean("empDao",EmpDao.class);
		EmpDao dao2=ctx.getBean("empDao",EmpDao.class);
		
		try
		{
			System.out.println(dao1.getEmpList());
			System.out.println(dao1.hashCode());
			System.out.println(dao2.hashCode());

		}
		catch(EmpException e)
		{
		e.printStackTrace();	
		}*/
	
	EmpService service1=ctx.getBean("empService",EmpService.class);
	EmpService service2=ctx.getBean("empService",EmpService.class);
	
	try
	{
		System.out.println(service1.getEmpList());
		System.out.println(service1.hashCode());
		System.out.println(service2.hashCode());

	}
	catch(EmpException e)
	{
	e.printStackTrace();	
	}
	
		ctx.close();
		
	}
		
	

}
