package com.cg.java.config;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Configurable;
import org.springframework.context.ApplicationContext;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Lazy;
import org.springframework.context.annotation.Scope;

import com.cg.java.dao.EmpDao;
import com.cg.java.dao.EmpDaoImpl;
import com.cg.java.services.EmpService;
import com.cg.java.services.EmpServiceImpl;

/*
 * @Configuration:
 * it is class level annotation 
 * Declares a class as Configuration class
 * 
 * 
 * @Bean
 * Method level
 * Declares  a method as factory method
 * factory method:
 * a method responsible  for  creating,initializing a object is called factory method
 * 
 * 
 * The @Lazy and @Scope  are also allowed on factory methods 
 * 
 * 
 */

@Configurable
public class ProjectConfig {
	@Autowired
	ApplicationContext ctx;
	@Bean("empDao")
//	@Lazy(true)
//	@Scope("prototype")
	public EmpDao getEmpDao()
	{System.out.println("object created");
		return new EmpDaoImpl();	
	}
	
	@Bean("empService")
			public EmpService  getEmpService()
			{
	EmpDao dao=ctx.getBean("empDao",EmpDao.class);
		EmpService service =new EmpServiceImpl();
		service.setDao(dao);
				return service;
			}
			
			
	
	
	
	
}
