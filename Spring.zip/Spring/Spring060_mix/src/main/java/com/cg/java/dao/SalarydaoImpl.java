package com.cg.java.dao;

import java.util.ArrayList;
import java.util.List;

import com.cg.java.dto.EmpSal;
import com.cg.java.exceptions.EmpException;

public class SalarydaoImpl implements SalaryDao {

	@Override
	public List<EmpSal> getEmpSalList() throws EmpException {
		List<EmpSal>   empSalList=new ArrayList<EmpSal>();
		empSalList.add(new EmpSal(1,25000,5000));
		empSalList.add(new EmpSal(2,35000,6000));
		empSalList.add(new EmpSal(1,45000,7000));
		
		
		return empSalList;
	}

}
