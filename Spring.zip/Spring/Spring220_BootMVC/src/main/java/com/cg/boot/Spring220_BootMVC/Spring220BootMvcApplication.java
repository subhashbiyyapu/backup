package com.cg.boot.Spring220_BootMVC;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class Spring220BootMvcApplication {

	public static void main(String[] args) {
		SpringApplication.run(Spring220BootMvcApplication.class, args);
	}

}
