package com.cg.boot.Spring220_BootMVC;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class Spring220BootMvcApplicationTests {

	@Test
	void contextLoads() {
	}

}
