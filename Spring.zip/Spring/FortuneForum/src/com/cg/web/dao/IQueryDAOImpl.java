package com.cg.web.dao;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.Query;

import org.springframework.stereotype.Repository;


import com.cg.web.dto.QueryMaster;
import com.cg.web.exception.QueryException;

@Repository

public class IQueryDAOImpl implements IQueryDAO  {

	@PersistenceContext
	private EntityManager manager;

	@Override
	public QueryMaster fetchQueryBasedOnId(int queryNo)throws QueryException {
		//if there is any error in getting data from database ,that exception is caught by custome exception
		try
		{
		 return manager.find(QueryMaster.class, queryNo);
		}
		catch(Exception e)
		{
			throw new QueryException("Error while procuring data");
		}
		}

		

}
