package com.cg.web.dao;

import com.cg.web.dto.QueryMaster;
import com.cg.web.exception.QueryException;

public interface IQueryDAO {

	QueryMaster fetchQueryBasedOnId(int queryNo)  throws QueryException;

}
