package com.cg.web.service;

import com.cg.web.dto.QueryMaster;
import com.cg.web.exception.QueryException;

public interface IQueryService {
	QueryMaster getQueryDetails(int queryNo) throws QueryException;

}
