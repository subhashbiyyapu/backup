package com.cg.web.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Scope;
import org.springframework.stereotype.Service;

import com.cg.web.dao.IQueryDAO;
import com.cg.web.dto.QueryMaster;
import com.cg.web.exception.QueryException;
@Service
@Scope("singleton")
public class IQueryServiceImpl implements IQueryService {
@Autowired
IQueryDAO dao;

	@Override
	public QueryMaster getQueryDetails(int queryNo) throws QueryException {
	return dao.fetchQueryBasedOnId(queryNo);
		
	}

}
