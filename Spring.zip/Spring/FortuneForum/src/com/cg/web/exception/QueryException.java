package com.cg.web.exception;

public class QueryException extends Exception {
	 public QueryException(String message)
	{
		super(message);
	}
public  QueryException(String message ,Throwable t)
	{
		super(message,t);
	}

}
