package com.cg.web.controllers;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.servlet.ModelAndView;

import com.cg.web.dto.QueryMaster;
import com.cg.web.exception.QueryException;
import com.cg.web.service.IQueryService;

@Controller
@RequestMapping("/querySearch")
public class QueryController {
	
	@Autowired
	private IQueryService service ; 
	
	
	@RequestMapping("/home.do")
	public String getHomePage()
	{
		return "Home";
	}
	@RequestMapping("/validateId.do")
	public ModelAndView authenticate(@RequestParam("id")  int queryNo)
	{	QueryMaster queryObj=null;
		try
		{
	queryObj=service.getQueryDetails(queryNo);
		}
		catch(QueryException e)
		{
			e.printStackTrace();
		}
		ModelAndView mandv=null;
		/*
		 * if the object returned is null it is redirected to error page
		 * else
		 * object is added to modelAndView and redirected to QueryDetailsPage
		 */
		if(queryObj==null)
			
		{
			
			mandv=new ModelAndView("ErrorPage");
			mandv.addObject("id",queryNo);
		}
		else
		{
			mandv=new ModelAndView("QueryDetails");
			mandv.addObject("queryObj",queryObj);
			

		}
		
		return mandv;
	}
}
