package com.cg.java.tests;

import org.springframework.context.ApplicationContext;
import org.springframework.context.ConfigurableApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;
import com.cg.java.dao.EmpDao;
import com.cg.java.exceptions.EmpException;
import com.cg.java.services.EmpService;

public class Test050 {

	public static void main(String[] args) {
		
		ConfigurableApplicationContext cctx=new ClassPathXmlApplicationContext("SpringCore.xml");
/*EmpDao  dao=cctx.getBean("empDao",EmpDao.class);
try
{
System.out.println(dao.getEmpList());	
}
catch(EmpException e)
{
e.printStackTrace();	
}
*/
		
		EmpService  service=cctx.getBean("empServices",EmpService.class);
		try
		{
		System.out.println(service.getEmpList());	
		}
		catch(EmpException e)
		{
		e.printStackTrace();	
		}
	}

}
