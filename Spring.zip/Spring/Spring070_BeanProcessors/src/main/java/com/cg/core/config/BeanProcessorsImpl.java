package com.cg.core.config;

import java.beans.PropertyDescriptor;

import org.springframework.beans.BeansException;
import org.springframework.beans.PropertyValues;
import org.springframework.beans.factory.config.BeanPostProcessor;
import org.springframework.beans.factory.config.InstantiationAwareBeanPostProcessor;
import org.springframework.stereotype.Component;

import com.cg.core.dao.EmpDao;
import com.cg.core.dao.EmpDaoImpl;

/*\
 * BeanPostProcessors are created before all other beans

 *
 * 
 * BeanPostProcessor
 *        postProcessBeforeInitialization
 *        postProcessAfterInitialization
 *        
 * InstantiationAwareBeanPostProcessor is extended from BeanPostProcessor
 * 
 * 
 *        postProcessBeforeInstantiation
 *                   * the postProcessorBeforeInstantiation() is called for creating EmpDao
 *                     If this method returns instance of EmpDaoImpl   ,   bean is created
 *                     If this method returns null,spring invokes its own bean creation mechanism  
 *                                
 *        postProcessAfterInstantiation
 *                  if it returns false,it does not allow data injection
 *                  if it returns true,it allows data injection
 *        
 *        postProcessProperties
 *        postProcessPropertyValues
 */
@Component
public class BeanProcessorsImpl implements InstantiationAwareBeanPostProcessor, BeanPostProcessor {


	// 1.
	public Object postProcessBeforeInstantiation(Class<?> beanClass, String beanName) throws BeansException {

		// Logic to create programatically create a bean can go here
		System.out.println("post   Process   Before   Instantiation"+ " "+beanName);
		//System.out.println(beanClass.getName() + "  " + beanName);
		/*if (beanName.equals("empDao")) {
			EmpDao dao = new EmpDaoImpl();
			return dao;
		}*/
		return null;
	}

	// 2.
	public boolean postProcessAfterInstantiation(Object bean, String beanName) throws BeansException {
		System.out.println("post   Process   After   Instantiation"+ " "+beanName);
		return true;
	}

	
	// it comes from BeanPostProcessor
	//this method canbe used to validate the injections  in the bean
		public Object postProcessBeforeInitialization(Object bean, String beanName) throws BeansException {
			System.out.println("before initilaization"+ " "+beanName);
			System.out.println(bean);
return bean;		}
		
		// it comes from BeanPostProcessor
		//it is used to validate the data that was processed after initialization
		public Object postProcessAfterInitialization(Object bean, String beanName) throws BeansException {
			System.out.println("after initilaization"+ " "+beanName);
			System.out.println(bean);
return bean;		}
		
	
	
	  //3.
		public PropertyValues postProcessPropertyValues(PropertyValues pvs,
	  PropertyDescriptor[] pds, Object bean, String beanName) throws
	  BeansException { 
		  System.out.println(" post Process Property Values"+ " "+beanName);
		  // TODO Auto-generated method stub return
	return pvs; } 
	  
	  //4.
		public PropertyValues    postProcessProperties(PropertyValues pvs, Object bean, String beanName)
	  throws BeansException {
		 
		 System.out.println(" post  Process  Properties"+ " "+beanName);
	 return pvs; }
	 
	 
	
	
	
	



}
