package com.cg.core.dao;

import java.util.ArrayList;

import java.util.List;

import org.springframework.stereotype.Repository;

@Repository("salaryDao")
public class SalarydaoImpl implements SalaryDao {


		
	
	
}
