package com.cg.java.services;

public class EmployeeServices {
	private String companyName;
	private String address;
	private  float yearlypackage;
	private SalaryServices services;
	
	
	

	public EmployeeServices(String companyName, String address) {
		System.out.println("in 2 param constructor");
		this.companyName = companyName;
		this.address = address;
	}

	
	public EmployeeServices(String companyName, String address,float  yearlypackage) {
		System.out.println("in  3 param constructor");
		this.companyName = companyName;
		this.address = address;
		this.yearlypackage=yearlypackage;
		
	}

	public  EmployeeServices()
	{
		System.out.println("EmpService Object created");
	}
	
	public String getMessages()
	{
		System.out.println(services.calcSalary()  );
		return "Welcome to Spring Training"+companyName;
		
	}
	//Properties
	public String getCompanyName() {//companyName
		return companyName;
	}

	public void setCompanyName(String companyName) {
		this.companyName = companyName;
	}

	public String getAddress() {
		return address;
	}

	public void setAddress(String address) {
		this.address = address;
	}

	public SalaryServices getServices() {
		return services;
	}

	public void setServices(SalaryServices services) {//services
		this.services = services;
	}

	
	
}
