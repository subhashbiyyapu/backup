package com.cg.java.services;

import javax.annotation.PostConstruct;
import javax.annotation.PreDestroy;

import org.springframework.beans.factory.DisposableBean;
import org.springframework.beans.factory.InitializingBean;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.Lazy;
import org.springframework.context.annotation.Scope;
import org.springframework.stereotype.Component;
import org.springframework.stereotype.Service;

/*
 *
 * 
 * @PostConstruct:
 *  An annotation given by java
 *  It declares an init method for a bean
 *  After creating a bean ,Spring context calls this method automatically
 *  This approach allows naming the method suitable to domain activity;
 *  It is used to  create resources
 *  
 *  
 *  @PreDestroy 
 *  An annotation given by java 
 *  It declares a finalizing method for a bean
 *  At the time of bean being removed from Spring context
 *  It is used to clean resources
 *  Method can be different as per the aim of the method
 *  
 *  
 *  Both the annotation come from javax annotations 
 *  Both ideally should be preferred over Spring bean life cycle(Ex: Disposable in Spring020)
 *  Both are method level annotations
 *  
 *  
 *  @Scope:
 *  To declare singleton or prototype for a bean 
 *  @Scope("singleton")  or @Scope("prototype")
 *  
 *  Each bean  by default is created eagerly ie; at the time of creation of Spring Context creation
 *  @Lazy(false) 
 *  @Lazy(true) to create an instance lazily
 *  
 *  
 *  
 *  
 *  @Component:to create a bean 
 *  Sub annotations are for documentation purpose
 *  
 *           @Repository:To declare  DAO classes as bean 
 *           @Service:     to declare  Business Logic /Service as beans
 *           @Controller:   It is used  to declare  controlling classes in Spring MVC
 *           @RestController:To declare  REST Services from a class in Spring REST
 *           
 *           
 *  
 */
@Service("empServices")
@Scope("singleton")
@Lazy(true)
public class EmployeeServices //implements InitializingBean,DisposableBean
{
	@Value("Capgemini,pune")
	private String companyName;
	
	private String address;
	@Value("80000")
	private  float yearlypackage;

	private SalaryServices services;
	
	
	

	public EmployeeServices(String companyName, String address) {
		System.out.println("in 2 param constructor");
		this.companyName = companyName;
		this.address = address;
	}

	
	public EmployeeServices(String companyName, String address,float  yearlypackage) {
		System.out.println("in  3 param constructor");
		this.companyName = companyName;
		this.address = address;
		this.yearlypackage=yearlypackage;
		
	}

	public  EmployeeServices()
	{
		System.out.println("EmpService Object created");
	}
	
	public String getMessages()
	{
		System.out.println(services.calcSalary()  );
		return "Welcome to Spring Training"+companyName;
		
	}
	//Properties
	public String getCompanyName() {//companyName
		return companyName;
	}

	public void setCompanyName(String companyName) {
		this.companyName = companyName;
	}

	public String getAddress() {
		return address;
	}
	@Value("talwade")
	public void setAddress(String address) {
		this.address = address;
	}

	public SalaryServices getServices() {
		return services;
	}
	@Autowired
	//By type:    Find the bean as per the type and not on "id"
	//Byname : find bean on basis of Id
	@Qualifier("salServices")
	public void setServices(SalaryServices services) {//services
		System.out.println("Setter method");
		this.services = services;
	}

@PostConstruct
	public void initailizingResources() throws Exception {
		
	System.out.println("in initailizingResources()");
	
	}

@PreDestroy
	public void closingResources() throws Exception {
		
		System.out.println("closingResources");
		
	}
	

	
	
}
