package com.cg.core.services;

public interface EmpService {
	
	String authenticate(String username,String password);
	

}
