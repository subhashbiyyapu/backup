package com.cg.core.services;

import org.springframework.context.annotation.Scope;
import org.springframework.stereotype.Service;

@Service
@Scope("singleton")
public class EmpSeviceImpl implements EmpService {

	
	public String authenticate(String username, String password) {
		System.out.println("authneticate");
		if(username.equals("subhash") &&  password.equals("mahesh"))
		{
			return "Biyyapu Subhash";
		}
		else
		{
			return null;
		}
	
	}

}
