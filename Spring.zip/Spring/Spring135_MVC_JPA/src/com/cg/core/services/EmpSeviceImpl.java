package com.cg.core.services;

import java.util.List;



import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Scope;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Propagation;
import org.springframework.transaction.annotation.Transactional;

import com.cg.core.dao.EmpDao;
import com.cg.core.dto.Emp;
import com.cg.core.exceptions.EmpException;
/*
 * 
 * Transactions  :
 *  REQUIRES-NEW:;aways start a new transaction
 *  REQUIREDwill work in sxisting transaction,otherwise runs a new transaction
 *  MANDATORY doesnot create new ,but must work on existing
 *  NEVER must never work in any transaction
 *  SUPPORTED doesnot need the transaction but can propogate 
 *  NOT-SUPPORTED does not need the trnsaction and doesnot work on it
 *  
 *  
 * 
 */
@Service
@Scope("singleton")
public class EmpSeviceImpl implements EmpService {
@Autowired
	private  EmpDao dao;
	
	public String authenticate(String username, String password) {
		System.out.println("authneticate");
		if(username.equals("subhash") &&  password.equals("mahesh"))
		{
			return "Biyyapu Subhash";
		}
		else
		{
			return null;
		}
	
	}
	
	@Override
	public List<Emp> getEmpList() throws EmpException{
		
		return dao.getEmpList();
	}

	@Override
	@Transactional(propagation=Propagation.REQUIRES_NEW)
	public Emp joinNewEmp(Emp emp) throws EmpException {
		
		
		return dao.insertNewEmp(emp);
	}

}
