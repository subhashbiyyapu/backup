package com.cg.core.dto;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity

@Table(name="Emp_table")
public class Emp {

	@Id
	@Column(name="empId")
	private int empId;
	@Column(name="firstname")
	private String firstName;
	@Column(name="salary")
	private float salary;
	public Emp(int empId, String firstName, float salary) {
		super();
		this.empId = empId;
		this.firstName = firstName;
		this.salary = salary;
	}
	public Emp() {
		super();
	}
	public int getEmpId() {
		return empId;
	}
	public void setEmpId(int empId) {
		this.empId = empId;
	}
	public String getFirstName123() {
		return firstName;
	}
	public void setFirstName(String firstName) {
		this.firstName = firstName;
	}
	public float getSalary() {
		return salary;
	}
	public void setSalary(float salary) {
		this.salary = salary;
	}
	
}
