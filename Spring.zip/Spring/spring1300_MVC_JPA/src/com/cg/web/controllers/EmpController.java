package com.cg.web.controllers;

import java.util.List;

import javax.servlet.ServletRequest;

import javax.servlet.http.HttpServletRequest;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpRequest;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.servlet.ModelAndView;

import com.cg.core.dto.Emp;
import com.cg.core.exceptions.EmpException;
import com.cg.core.services.EmpService;
//http://localhost:8080/Spring1000_MVCBasics/empService/home.do
@Controller
@RequestMapping("/empService")
public class EmpController {
	@Autowired
	private EmpService service ; 
	
	
	
	@RequestMapping("/home.do")
	/*
	 * bean name url handler                by default
	 * simple url handler
	 * class name url handler
	 */
	public String getHomePage()
	{
		//return "/WEB-INF/jsps/Home.jsp";
		return "Home";
	}
	@RequestMapping("/login.do")
	public String getLoginPage()
	{
		//return "/WEB-INF/jsps/Login.jsp";
		return "Login";
	}
	//action methods
	@RequestMapping("/authenticate.do")
	public ModelAndView authenticate(@RequestParam("username")  String username,@RequestParam("password")  String password)
	{
		/*String username=req.getParameter("username");
		String password=req.getParameter("password");*/
		System.out.println(username+  "      "+password);
		String fullname=service.authenticate(username, password);
		ModelAndView mandv=null;
		if(fullname==null)
		{mandv=new ModelAndView("Login");
		mandv.addObject("msg","invalid username or password");
		//	return "Login";
		}
		else
		{
		//return "/WEB-INF/jsps/MainMenu.jsp";
			mandv=new ModelAndView("MainMenu");
			mandv.addObject("fullname",fullname);

	//	return "MainMenu";
		}
		
		return mandv;
	}
	
	
	@RequestMapping("/empList.do")
	public ModelAndView getEmpList()
	{ 
		List<Emp> empList=null;
		try {
			empList = service.getEmpList();
		} catch (EmpException e) {

			e.printStackTrace();
		}
		ModelAndView mAndV=new ModelAndView();
		mAndV.addObject("empList",empList);
		mAndV.setViewName("EmpList");
		return mAndV;
		
	}

}
