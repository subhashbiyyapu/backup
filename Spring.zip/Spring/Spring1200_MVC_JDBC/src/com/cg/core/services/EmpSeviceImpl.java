package com.cg.core.services;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Scope;
import org.springframework.stereotype.Service;

import com.cg.core.dao.EmpDao;
import com.cg.core.dto.Emp;
import com.cg.core.exceptions.EmpException;

@Service
@Scope("singleton")
public class EmpSeviceImpl implements EmpService {
@Autowired
	private  EmpDao dao;
	
	public String authenticate(String username, String password) {
		System.out.println("authneticate");
		if(username.equals("subhash") &&  password.equals("mahesh"))
		{
			return "Biyyapu Subhash";
		}
		else
		{
			return null;
		}
	
	}
	
	@Override
	public List<Emp> getEmpList() throws EmpException{
		
		return dao.getEmpList();
	}

}
