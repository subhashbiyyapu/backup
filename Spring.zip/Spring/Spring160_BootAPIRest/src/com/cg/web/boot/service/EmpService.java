package com.cg.web.boot.service;

import java.util.List;

import com.cg.web.boot.dto.Employee;

public   interface EmpService {
	List<Employee> getEmpList();
	Employee joinNewEmployee(Employee emp);
}
